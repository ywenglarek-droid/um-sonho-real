const KEY="um-sonho-real-data-v1";
let data=JSON.parse(localStorage.getItem(KEY)||'{"characters":[],"families":[],"timeline":[],"chapters":[],"places":[],"ideas":[],"playlist":[],"palette":"royal"}');
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
function save(){localStorage.setItem(KEY,JSON.stringify(data));renderAll()}
function esc(v=''){return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function nav(section){$$('.section').forEach(x=>x.classList.toggle('active',x.id===section));$$('.nav-btn').forEach(x=>x.classList.toggle('active',x.dataset.section===section));const names={dashboard:'Painel da Escritora',characters:'Personagens',families:'Famílias',timeline:'Linha do tempo',chapters:'Capítulos',places:'Lugares',ideas:'Ideias e anotações',playlist:'Playlist',settings:'Personalização'};$('#pageTitle').textContent=names[section]||'Painel da Escritora';window.scrollTo(0,0)}
$$('.nav-btn').forEach(b=>b.onclick=()=>nav(b.dataset.section));$$('[data-go]').forEach(b=>b.onclick=()=>nav(b.dataset.go));
$('#mobileMenu').onclick=()=>$('.sidebar').classList.toggle('open');

function openModal(title, fields, onSave){
  $('#modalTitle').textContent=title;
  $('#modalForm').innerHTML='<div class="form-grid">'+fields.map(f=>`<div class="field ${f.full?'full':''}"><label>${f.label}</label>${f.type==='textarea'?`<textarea name="${f.name}" placeholder="${f.placeholder||''}">${esc(f.value||'')}</textarea>`:f.type==='select'?`<select name="${f.name}">${f.options.map(o=>`<option ${o===f.value?'selected':''}>${o}</option>`).join('')}</select>`:`<input type="${f.type||'text'}" name="${f.name}" value="${esc(f.value||'')}" placeholder="${f.placeholder||''}">`}</div>`).join('')+'</div><button class="primary-btn form-submit">Salvar</button>';
  $('#modal').classList.remove('hidden'); $('#modalForm').onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target);onSave(Object.fromEntries(fd));$('#modal').classList.add('hidden');save()}
}
$('#closeModal').onclick=()=>$('#modal').classList.add('hidden');$('#modal').onclick=e=>{if(e.target.id==='modal')$('#modal').classList.add('hidden')};

function characterForm(item={},idx=-1){
 openModal(idx>=0?'Editar personagem':'Novo personagem',[
 {name:'name',label:'Nome completo',placeholder:'Ex.: Isabella Wenglarek',value:item.name},
 {name:'surname',label:'Sobrenome / família',placeholder:'Ex.: Wenglarek',value:item.surname},
 {name:'age',label:'Idade',type:'number',value:item.age},
 {name:'role',label:'Papel na história',placeholder:'Protagonista, amigo...',value:item.role},
 {name:'image',label:'Link da imagem',placeholder:'Cole um link de imagem',value:item.image,full:true},
 {name:'description',label:'Descrição e personalidade',type:'textarea',value:item.description,full:true},
 {name:'relations',label:'Relações familiares',placeholder:'Ex.: filha de X; irmã de Y',value:item.relations,full:true},
 {name:'secrets',label:'Segredos / informações importantes',type:'textarea',value:item.secrets,full:true}
 ],v=>{if(idx>=0)data.characters[idx]=v;else data.characters.push(v)})
}
$('#addCharacter').onclick=()=>characterForm();
function renderCharacters(){let el=$('#charactersGrid');el.innerHTML=data.characters.length?data.characters.map((c,i)=>`<article class="item-card"><div class="item-image" ${c.image?`style="background-image:url('${esc(c.image)}')"`:''}>${c.image?'':'♙'}</div><div class="item-content"><h3>${esc(c.name||'Sem nome')}</h3><span class="tag">${esc(c.surname||'Sem família')}</span><span class="tag">${esc(c.role||'Personagem')}</span><p>${esc(c.description||'Sem descrição ainda.')}</p><div class="actions"><button class="action-btn" onclick="characterForm(data.characters[${i}],${i})">Editar</button><button class="action-btn delete" onclick="removeItem('characters',${i})">Excluir</button></div></div></article>`).join(''):'<div class="empty">Ainda não há personagens. Clique em “Novo personagem” para começar.</div>'}

function familyForm(item={},idx=-1){
 openModal(idx>=0?'Editar família':'Nova família',[
 {name:'name',label:'Nome da família / sobrenome',placeholder:'Ex.: Família Wenglarek',value:item.name},
 {name:'description',label:'Descrição da família',type:'textarea',value:item.description,full:true},
 {name:'members',label:'Personagens associados',placeholder:'Separe os nomes por vírgula',value:item.members,full:true}
 ],v=>{if(idx>=0)data.families[idx]=v;else data.families.push(v)})
}
$('#addFamily').onclick=()=>familyForm();
function renderFamilies(){let el=$('#familiesGrid');let auto={};data.characters.forEach(c=>{if(c.surname){auto[c.surname]??=[];auto[c.surname].push(c.name)}});data.families.forEach(f=>{const key=(f.name||'').replace(/^Família\s+/i,'');if(key)auto[key]=[...(auto[key]||[]),...(f.members||'').split(',').map(x=>x.trim()).filter(Boolean)]});let entries=Object.entries(auto);el.innerHTML=entries.length?entries.map(([name,members])=>`<article class="card family-card"><h3>Família ${esc(name)}</h3><div class="family-members">${[...new Set(members)].map(m=>`<span class="member">♙ ${esc(m)}</span>`).join('')}</div></article>`).join('')+(data.families.length?data.families.map((f,i)=>`<article class="card family-card"><h3>${esc(f.name)}</h3><p>${esc(f.description||'')}</p><div class="actions"><button class="action-btn" onclick="familyForm(data.families[${i}],${i})">Editar</button><button class="action-btn delete" onclick="removeItem('families',${i})">Excluir</button></div></article>`).join(''):''):'<div class="empty">As famílias aparecerão automaticamente a partir dos sobrenomes dos personagens.</div>'}

function timelineForm(item={},idx=-1){
 openModal(idx>=0?'Editar acontecimento':'Novo acontecimento',[
 {name:'date',label:'Data / período',placeholder:'Ex.: 15 de setembro de 2026',value:item.date},
 {name:'title',label:'Título do acontecimento',placeholder:'Ex.: Isabella chega à Inglaterra',value:item.title},
 {name:'place',label:'Local',value:item.place},
 {name:'chapter',label:'Capítulo relacionado',value:item.chapter},
 {name:'description',label:'O que acontece?',type:'textarea',value:item.description,full:true},
 {name:'characters',label:'Personagens envolvidos',placeholder:'Separe os nomes por vírgula',value:item.characters,full:true}
 ],v=>{if(idx>=0)data.timeline[idx]=v;else data.timeline.push(v)})
}
$('#addTimeline').onclick=()=>timelineForm();
function renderTimeline(){let el=$('#timelineList');let arr=[...data.timeline].sort((a,b)=>String(a.date).localeCompare(String(b.date)));el.innerHTML=arr.length?arr.map((t)=>{const i=data.timeline.indexOf(t);return `<article class="timeline-item"><div class="timeline-date">${esc(t.date||'Sem data')}</div><h3>${esc(t.title||'Sem título')}</h3><p>${esc(t.description||'')}</p><span class="tag">⌖ ${esc(t.place||'Local não definido')}</span><span class="tag">▤ ${esc(t.chapter||'Sem capítulo')}</span><div class="actions"><button class="action-btn" onclick="timelineForm(data.timeline[${i}],${i})">Editar</button><button class="action-btn delete" onclick="removeItem('timeline',${i})">Excluir</button></div></article>`}).join(''):'<div class="empty">Sua linha do tempo está esperando o primeiro acontecimento.</div>'}

function genericForm(type,item={},idx=-1){
 const configs={chapters:['capítulo','title','Título do capítulo','Resumo e acontecimentos','summary'],places:['lugar','name','Nome do lugar','Descrição do lugar','description'],ideas:['ideia','title','Título da ideia','Anotação','description'],playlist:['música','title','Nome da música','Artista e capítulo/personagem relacionado','artist']};
 const c=configs[type];openModal(idx>=0?`Editar ${c[0]}`:`Nova ${c[0]}`,[{name:c[1],label:c[2],value:item[c[1]],full:true},{name:c[4],label:c[3],type:'textarea',value:item[c[4]],full:true}],v=>{if(idx>=0)data[type][idx]=v;else data[type].push(v)})
}
['chapters','places','ideas','playlist'].forEach(type=>{const id='#add'+type[0].toUpperCase()+type.slice(1,-1);$(id).onclick=()=>genericForm(type)})
function renderGeneric(type,elId,icon){let el=$(elId);let labels={chapters:'Capítulo',places:'Lugar',ideas:'Ideia',playlist:'Música'};el.innerHTML=data[type].length?data[type].map((x,i)=>`<article class="item-card"><div class="item-content"><span class="eyebrow">${labels[type]}</span><h3>${esc(x.title||x.name||'Sem título')}</h3><p>${esc(x.summary||x.description||x.artist||'')}</p><div class="actions"><button class="action-btn" onclick="genericForm('${type}',data.${type}[${i}],${i})">Editar</button><button class="action-btn delete" onclick="removeItem('${type}',${i})">Excluir</button></div></div></article>`).join(''):'<div class="empty">Ainda não há itens aqui.</div>'}

function removeItem(type,i){if(confirm('Excluir este item?')){data[type].splice(i,1);save()}}
function renderAll(){renderCharacters();renderFamilies();renderTimeline();renderGeneric('chapters','#chaptersGrid');renderGeneric('places','#placesGrid');renderGeneric('ideas','#ideasGrid');renderGeneric('playlist','#playlistGrid');$('#statCharacters').textContent=data.characters.length;$('#statChapters').textContent=data.chapters.length;$('#statTimeline').textContent=data.timeline.length;$('#statIdeas').textContent=data.ideas.length;$('#dashboardTimeline').innerHTML=data.timeline.slice(-3).reverse().map(t=>`<p><b>${esc(t.date||'')}</b> — ${esc(t.title||'')}</p>`).join('')||'<div class="empty">Sua linha do tempo aparecerá aqui.</div>';$('#dashboardIdeas').innerHTML=data.ideas.slice(-3).reverse().map(i=>`<p>✦ ${esc(i.title||'')}</p>`).join('')||'<div class="empty">Suas ideias aparecerão aqui.</div>'}
function applyPalette(p){const root=document.documentElement;const palettes={royal:['#6d536f','#4e3b52','#c5a47e','#f7f4f1'],dark:['#5d5367','#202124','#b99b72','#f1eff0'],rose:['#8b5262','#6b3d4e','#d9a99d','#faf4f2'],forest:['#55745f','#29443b','#c7a878','#f2f5f0']};const v=palettes[p]||palettes.royal;root.style.setProperty('--primary',v[0]);root.style.setProperty('--primary-dark',v[1]);root.style.setProperty('--accent',v[2]);root.style.setProperty('--bg',v[3]);data.palette=p;localStorage.setItem(KEY,JSON.stringify(data))}
$$('.palette').forEach(b=>b.onclick=()=>{applyPalette(b.dataset.palette);alert('Paleta aplicada!')});
$('#quickAdd').onclick=()=>{const active=$('.section.active').id;({characters:()=>characterForm(),families:()=>familyForm(),timeline:()=>timelineForm(),chapters:()=>genericForm('chapters'),places:()=>genericForm('places'),ideas:()=>genericForm('ideas'),playlist:()=>genericForm('playlist')}[active]||(()=>nav('characters')))()};
$('#exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='backup-um-sonho-real.json';a.click();URL.revokeObjectURL(a.href)}
$('#importInput').onchange=e=>{const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{try{data=JSON.parse(r.result);save();alert('Backup importado!')}catch{alert('Arquivo inválido.')}};r.readAsText(file)}
applyPalette(data.palette||'royal');renderAll();
