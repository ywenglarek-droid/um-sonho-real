# ✦ Um Sonho Real — Painel da Escritora

Um painel pessoal para planejar o livro **Um Sonho Real**.

## Recursos
- Personagens com imagem, personalidade, relações e segredos
- Famílias associadas automaticamente pelos sobrenomes
- Linha do tempo de acontecimentos
- Capítulos
- Lugares
- Ideias e anotações
- Playlist
- Paletas de cores
- Exportação e importação de backup em JSON
- Dados salvos no navegador com localStorage

## Como colocar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie `index.html`, `style.css` e `script.js`.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde o GitHub gerar o link do site.

> Importante: os dados ficam salvos no navegador que você usar. Use o botão **Exportar backup** para guardar uma cópia dos seus dados.
